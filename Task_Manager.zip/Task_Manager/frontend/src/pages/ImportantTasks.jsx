import React from 'react'
import Cards from '../components/Home/Cards'

const ImportantTasks = () => {
  return (
    <div>
      <Cards home = {"false"}/>
    </div>
  )
}

export default ImportantTasks