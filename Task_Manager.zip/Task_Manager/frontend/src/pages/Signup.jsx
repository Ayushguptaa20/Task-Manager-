import React, {useState} from 'react'
import {Link} from "react-router-dom"
import axios from "axios";
const Signup = () => {
  const [Data, setData] = useState({ username: "", email:"", password:"" });
  const change = (e) => {
    const { name, value } = e.target;
    setData({...Data, [name]:value})
  }
  const submit = async () => {
    try {
      if(Data.username === "" || Data.email === "" || Data.password === "" ){
        alert("All fields are required")
      }else{
        const response = await axios.post("http://localhost:1000/api/v1/sign-in", Data);
        console.log(response);
      }
    }
    catch (error) {
      console.log(error.response.Data)
    }};
  return (
    <div className='h-[98vh] flex items-center justify-center'>
        <div className='p-4 w2/6 rounded bg-gray-800'>
            <div className='text-2xl font-semibold'>Sign-up</div>
            <input type="username" placeholder='username' className='bg-gray-700 px-3 py-2 my-3 w-full rounded' name='username' value = {Data.username}onChange={change}/>
            <input type="email" placeholder='email' className='bg-gray-700 px-3 py-2 my-3 w-full rounded' name='abc@example.com' required value = {Data.email}onChange={change}/>
            <input type="username" placeholder='password' className='bg-gray-700 px-3 py-2 my-3 w-full rounded' name='password' value = {Data.password}onChange={change}/>
            <div className='w-full flex items-center justify-between'>
                <button className='bg-blue-400 font-semibold px-3 py-2 rounded' onClick={{submit}}>
                    Signup
                </button>
                <Link to="/Login" className='text-gray-400 hover:text-gray-200'>Already Having an Account ? Click Here</Link>
            </div>

        </div>
    </div>
  )
}

export default Signup